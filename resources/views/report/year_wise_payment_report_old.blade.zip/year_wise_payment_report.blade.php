@extends('layouts.app')

@section('style')

    <style>
        .img-overlay {
            position: absolute;
            left: 0;
            top: 150px;
            width: 100%;
            height: 100%;
            overflow: hidden;
            text-align: center;
            z-index: 9;
            opacity: 0.2;
        }

        .img-overlay img {
            width: 400px;
            height: auto;
        }
    </style>
@endsection

@section('title')
    Project Wise Report
@endsection

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Filter</h3>
                </div>
                <!-- /.box-header -->

                <div class="box-body">
                    <form action="{{ route('report.year_wise_payment') }}">
                        <div class="row">
                            {{--                            <div class="col-md-4">--}}
                            {{--                                <div class="form-group">--}}
                            {{--                                    <label>Start Date</label>--}}

                            {{--                                    <div class="input-group date">--}}
                            {{--                                        <div class="input-group-addon">--}}
                            {{--                                            <i class="fa fa-calendar"></i>--}}
                            {{--                                        </div>--}}
                            {{--                                        <input type="text" class="form-control pull-right"--}}
                            {{--                                               id="start" name="start" value="{{ request()->get('start')  }}" autocomplete="off">--}}
                            {{--                                    </div>--}}
                            {{--                                    <!-- /.input group -->--}}
                            {{--                                </div>--}}
                            {{--                            </div>--}}

                            {{--                            <div class="col-md-4">--}}
                            {{--                                <div class="form-group">--}}
                            {{--                                    <label>End Date</label>--}}

                            {{--                                    <div class="input-group date">--}}
                            {{--                                        <div class="input-group-addon">--}}
                            {{--                                            <i class="fa fa-calendar"></i>--}}
                            {{--                                        </div>--}}
                            {{--                                        <input type="text" class="form-control pull-right"--}}
                            {{--                                               id="end" name="end" value="{{ request()->get('end')  }}" autocomplete="off">--}}
                            {{--                                    </div>--}}
                            {{--                                    <!-- /.input group -->--}}
                            {{--                                </div>--}}
                            {{--                            </div>--}}
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Project</label>
                                    <select class="form-control" name="project" required="">
                                        <option value="">Select Project</option>
                                        @foreach($projects as $project)
                                            <option {{ request()->get('project') == $project->id ? 'selected' : '' }} value="{{$project->id}}">{{$project->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>	&nbsp;</label>
                                    <input class="btn btn-primary form-control" type="submit" value="Submit">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12" style="min-height:300px">
            @if($customers)
                <section class="panel">

                    <div class="panel-body">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea')">Print</button><br><hr>
                        <div class="adv-table" id="prinarea">
                            <div class="row">
                                <div class="col-xs-4 text-left">
                                    <img style="width: 35%;margin-top: 20px" src="{{ asset('img/head_logo.jpeg') }}">
                                </div>
                                <div class="col-xs-8 text-center">
                                    <div style="padding:10px; width:100%; text-align:center;">
                                        <h2>{{\App\Enumeration\Text::$companyName}}</h2>
                                        <h4>{{\App\Enumeration\Text::$companyAddress}}</h4>
                                        <h4>{{\App\Enumeration\Text::$companyMobileNumber}}</h4>
                                        <h4>{{\App\Enumeration\Text::$companyEmail}}</h4>
                                    </div>
                                </div>
                                <div class="col-xs-12 text-center">
                                    <h3><strong>Receipt</strong></h3>
                                    <h4>{{ $project_single->name??'' }}</h4>
                                </div>
                            </div>

                            <div style="clear: both">
                                <div class="img-overlay">
                                    <img src="{{ asset('img/logo.png') }}">
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Order No.</th>
                                            <th class="text-center">Project Name</th>
                                            <th class="text-center">Client Name</th>
                                            <th class="text-center">Mobile No.</th>
                                            <th class="text-center">Floor No.</th>
                                            <th class="text-center">Flat No.</th>
                                            <th class="text-center">2022</th>
                                            <th class="text-center">2023</th>
                                            <th class="text-center">2024</th>
                                            <th class="text-center">2025</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        @foreach($customers as $row)
                                            <tr>
                                                <td colspan="2">{{ $row->client->name }}</td>
                                            </tr>
                                        @endforeach
                                        <tr>
                                            <th colspan="6">Total</th>
                                            <th class="text-center"> {{ number_format($customers->sum('total'),2) }}</th>
                                            <th class="text-center"> {{ number_format($customers->sum('paid'),2) }}</th>
                                            <th class="text-center"> {{ number_format($customers->sum('due'),2) }}</th>
                                            <th class="text-center"> {{ number_format($customers->sum('due'),2) }}</th>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            @endif
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function () {
            //Date picker
            $('#start, #end').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
        });
        var APP_URL = '{!! url()->full()  !!}';
        function getprint(print) {

            $('body').html($('#'+print).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
@endsection
