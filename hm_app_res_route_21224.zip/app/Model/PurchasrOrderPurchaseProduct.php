<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PurchasrOrderPurchaseProduct extends Model
{
    protected $table = 'purchase_order_purchase_product';
}
