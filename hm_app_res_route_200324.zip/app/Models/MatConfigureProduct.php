<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MatConfigureProduct extends Model
{
    use HasFactory;
    protected $table = 'mat_configure_products';
    protected $guarded = [];
}
