<?php
namespace App\Enumeration;

class Text {
    public static $companyName = "HM Engineering";
    public static $companyAddress = "2nd Floor,7 Masjid SuperMarket,Mohammadpur";
    public static $companyMobileNumber = "Mobile : 01730724800";
    public static $companyEmail = "Email : hm_engineering@gmail.com";
}
