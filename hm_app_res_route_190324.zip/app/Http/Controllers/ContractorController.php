<?php

namespace App\Http\Controllers;

use App\Model\Project;
use App\Model\TransactionLog;
use App\Models\Contractor;
use App\Models\ReceiptPayment;
use App\Models\ReceiptPaymentDetail;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Ramsey\Uuid\Uuid;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class ContractorController extends Controller
{
    public function contractorAll() {
        $contractors = Contractor::where('status', 1)->get();
        return view('labour.contractor.all',compact('contractors'));
    }

    public function contractorAdd() {
        $projects = Project::where('status', 1)->get();
        return view('labour.contractor.add', compact('projects'));
    }

    public function contractorAddPost(Request $request) {
    //    dd($request->all());
        $request->validate([
            'name' => 'required|string|max:255',
            'project_id' => 'nullable',
            'contractor_id' => 'required|string|max:255',
            'image' => 'nullable|mimes:jpg,png,jpeg',
            'nid' => 'nullable',
            'mobile' => 'required|digits:11',
            'address' => 'required|string|max:255',
            'status' => 'required'
        ]);
        $imagePath = null;
        if ($request->image) {
            // Upload Image
            $file = $request->file('image');
            $filename = Uuid::uuid1()->toString().'.'.$file->getClientOriginalExtension();
            $destinationPath = 'public/uploads/contractor';
            $file->move($destinationPath, $filename);
            $imagePath = 'uploads/contractor/'.$filename;
        }

        $contractor = new Contractor();
        $contractor->name = $request->name;
        $contractor->contractor_id = $request->contractor_id;
        $contractor->project_id = $request->project_id;
        $contractor->trade = $request->trade;
        $contractor->image = $imagePath;
        $contractor->mobile = $request->mobile;
        $contractor->nid = $request->nid;
        $contractor->address = $request->address;
        $contractor->status = $request->status;
        $contractor->save();

        return redirect()->route('contractor.all')->with('message', 'Contractor add successfully.');
    }

    public function contractorEdit(Contractor $contractor) {
        $projects = Project::where('status', 1)->get();
        return view('labour.contractor.edit', compact('contractor','projects'));
    }

    public function contractorEditPost(Contractor $contractor, Request $request) {
        $request->validate([
            'name' => 'required|string|max:255',
            'project_id' => 'nullable',
            'contractor_id' => 'required|string|max:255',
            'image' => 'nullable|mimes:jpg,png,jpeg',
            'nid' => 'nullable',
            'mobile' => 'required|digits:11',
            'address' => 'required|string|max:255',
            'status' => 'required'
        ]);

        $imagePath = $contractor->image;

        if ($request->image) {

            if ($contractor->image){
                // Previous Photo
                $previousPhoto = public_path($contractor->image);
                unlink($previousPhoto);
            }

            // Upload Image
            $file = $request->file('image');
            $filename = Uuid::uuid1()->toString().'.'.$file->getcontractorOriginalExtension();
            $destinationPath = 'public/uploads/contractor';
            $file->move($destinationPath, $filename);

            $imagePath = 'uploads/contractor/'.$filename;
        }
        $contractor->name = $request->name;
        $contractor->contractor_id = $request->contractor_id;
        $contractor->project_id = $request->project_id;
        $contractor->trade = $request->trade;
        $contractor->image = $imagePath;
        $contractor->mobile = $request->mobile;
        $contractor->nid = $request->nid;
        $contractor->address = $request->address;
        $contractor->status = $request->status;
        $contractor->save();


        return redirect()->route('contractor.all')->with('message', 'Contractor edit successfully.');
    }
    public function contractorDelete(Contractor $contractor){
        Contractor::find($contractor->id)->delete();
        return redirect()->route('contractor.all')->with('message', 'Contractor Info Deleted Successfully.');
    }


    public function datatable() {
        $query = Contractor::with('projects');

        return DataTables::eloquent($query)
            ->addColumn('project', function(Contractor $contractor) {
                return $contractor->projects->name ?? '';
            })
            ->addColumn('action', function(Contractor $contractor) {
                $btn = '';
                $btn = '<a class="btn btn-info btn-sm" href="'.route('contractor.edit', ['contractor' => $contractor->id]).'">Edit</a>';
                $btn .= '<a href="'.route('contractor.delete', ['contractor' => $contractor->id]).'" onclick="return confirm(`Are you sure remove this item ?`)" class="btn btn-danger btn-sm btn_delete" style="margin-left: 3px;">Delete</a>';
                return $btn;
            })
            ->editColumn('image', function(Contractor $contractor) {
                return '<img width="50px" heigh="50px" src="'.asset($contractor->image ?? 'img/no_image.png').'" />';
            })
            ->editColumn('total', function(Contractor $contractor) {
                return ' '.number_format($contractor->total, 2);
            })
            ->editColumn('paid', function(Contractor $contractor) {
                return ' '.number_format($contractor->paid, 2);
            })
            ->editColumn('due', function(Contractor $contractor) {
                return ' '.number_format($contractor->due, 2);
            })
            ->editColumn('trade', function (Contractor $contractor) {
                if ($contractor->trade == 1)
                    return '<span class="label label-success">Civil Contractor</span>';
                elseif($contractor->trade == 2)
                    return '<span class="label label-warning">Paint Contractor</span>';
                elseif($contractor->trade == 3)
                    return '<span class="label label-primary">Sanitary Contractor</span>';
                elseif($contractor->trade == 4)
                    return '<span class="label label-info">Tiles Contractor</span>';
                elseif($contractor->trade == 5)
                    return '<span class="label label-info">MS Contractor</span>';
                elseif($contractor->trade == 6)
                    return '<span class="label label-info">Wood Contractor</span>';
                elseif($contractor->trade == 7)
                    return '<span class="label label-info">Electric Contractor</span>';
                elseif($contractor->trade == 8)
                    return '<span class="label label-info">Thai Contractor</span>';
                else
                    return '<span class="label label-danger">Other Contractor</span>';
            })
            ->editColumn('status', function(Contractor $contractor) {
                if ($contractor->status == 1)
                    return '<span class="label label-success">Active</span>';
                else
                    return '<span class="label label-danger">Inactive</span>';
            })
            ->rawColumns(['action', 'status','image','trade'])
            ->toJson();
    }
    public function supplierPayment() {
        $contractors = Contractor::where('status',1)->get();
        // dd($suppliers);
        return view('labour.supplier_payment.all', compact('contractors'));
    }
    public function makePayment(Request $request) {
        // dd($request->all());

        $rules = [
            'financial_year' => 'required',
            // 'order' => 'required',
            'project' => 'nullable',
            'payment_type' => 'required',
            'account' => 'required',
            'amount' => 'required|numeric|min:1',
            'date' => 'required|date',
            'note' => 'nullable|string|max:255',
        ];

        if ($request->payment_type == 1) {
            $rules['cheque_date'] = 'required';
            $rules['cheque_no'] = 'nullable|string|max:255';
            $rules['cheque_image'] = 'nullable|image';
        }
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => $validator->errors()->first()]);
        }
        $order =Contractor::find($request->supplier);
        // dd($order);
        $rules['amount'] = 'required|numeric|min:0|max:'.$order->due;


        $validator = Validator::make($request->all(), $rules);

        // if ($validator->fails()) {
        //     return response()->json(['success' => false, 'message' => $validator->errors()->first()]);
        // }

        // $order = PurchaseOrder::find($request->order);

        // $supplier->decrement('due', $request->amount);
        // $supplier->decrement('paid', $request->amount);
        $order->increment('paid', $request->amount);
        $order->decrement('due', $request->amount);

        //create dynamic voucher no process start
        $transactionType = 2;
        $financialYear = $request->financial_year;
        $cashBankAccountHeadId = $request->account;
        $payType = $request->payment_type;
        $voucherNo = generateVoucherReceiptNo($financialYear,$cashBankAccountHeadId,$transactionType,$payType);
        //create dynamic voucher no process end
        $receiptPaymentNoExplode = explode("-",$voucherNo);

        $receiptPaymentNoSl = $receiptPaymentNoExplode[1];
        $receiptPayment = new ReceiptPayment();

        $receiptPayment->project_id = $order->project_id;
        $receiptPayment->receipt_payment_no = $voucherNo;
        $receiptPayment->financial_year = financialYear($request->financial_year);
        $receiptPayment->date = Carbon::parse($request->date)->format('Y-m-d');
        $receiptPayment->transaction_type = 2;
        $receiptPayment->payment_type = $request->payment_type;//cash == 2,bank =1

        $receiptPayment->account_head_id = $request->account;
        $receiptPayment->cheque_no = $request->cheque_no;
        if ($request->payment_type == 1){
            $receiptPayment->cheque_date = Carbon::parse($request->cheque_date)->format('Y-m-d');
        }
        // $receiptPayment->client_id = $supplier->id;
        // $receiptPayment->customer_id = $supplier->id_no;
        $receiptPayment->sub_total = $request->amount;
        $receiptPayment->net_amount = $request->amount;
        $receiptPayment->purchase_order_id = $order->id;
        $receiptPayment->notes = $request->note;
        $receiptPayment->save();

        //Bank/Cash Credit
        // $log = new TransactionLog();
        // $log->notes = $request->note;
        // $log->project_id = $order->project_id;
        // $log->receipt_payment_no = $receiptPayment->receipt_payment_no;
        // $log->receipt_payment_sl = $receiptPaymentNoSl;
        // $log->financial_year = $receiptPayment->financial_year;
        // $log->client_id = $receiptPayment->client_id;
        // $log->date = $receiptPayment->date;
        // $log->receipt_payment_id = $receiptPayment->id;

        // if($request->payment_type == 1){
        //     $log->cheque_no = $request->cheque_no;
        //     $log->cheque_date = Carbon::parse($request->date)->format('Y-m-d');

        // }
        // $log->transaction_type = 2;//Bank Credit,Cash credit

        // $log->payment_type = $request->payment_type;
        // $log->account_head_id = $request->account;
        // $log->amount = $receiptPayment->net_amount;
        // $log->notes = $receiptPayment->notes;
        // $log->purchase_order_id = $order->id;
        // $log->save();

        $receiptPaymentDetail = new ReceiptPaymentDetail();
        $receiptPaymentDetail->receipt_payment_id = $receiptPayment->id;
        // $receiptPaymentDetail->account_head_id = 12;
        $receiptPaymentDetail->account_head_id = $request->account;
        $receiptPaymentDetail->amount = $request->amount;
        $receiptPaymentDetail->net_amount = $request->amount;
        $receiptPaymentDetail->save();

        //Debit Head Amount
        $log = new TransactionLog();
        $log->notes = $request->note;
        $log->project_id = $order->project_id;
        $log->receipt_payment_no = $voucherNo;
        $log->receipt_payment_sl = $receiptPaymentNoSl;
        $log->financial_year = financialYear($request->financial_year);
        // $log->client_id = $supplier->id;
        $log->date = Carbon::parse($request->date)->format('Y-m-d');
        $log->receipt_payment_id = $receiptPayment->id;
        $log->receipt_payment_detail_id = $receiptPaymentDetail->id;
        $log->payment_type = $request->payment_type;
        if($request->payment_type == 1){
            $log->cheque_no = $request->cheque_no;
            $log->cheque_date = Carbon::parse($request->cheque_date)->format('Y-m-d');
        }
        $log->transaction_type = 1;//Account Head Debit
        $log->account_head_id = $request->account;
        $log->purchase_order_id = $order->id;
        $log->amount = $request->amount;
        $log->notes = $request->note;
        $log->save();


        return response()->json(['success' => true, 'message' => 'Payment has been completed.', 'redirect_url' => route('voucher_details', ['receiptPayment' => $receiptPayment->id])]);
    }
}
