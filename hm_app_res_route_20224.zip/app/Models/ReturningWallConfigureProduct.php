<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReturningWallConfigureProduct extends Model
{
    use HasFactory;
    protected $table = 'returning_wall_configure_products';
    protected $guarded = [];
}
