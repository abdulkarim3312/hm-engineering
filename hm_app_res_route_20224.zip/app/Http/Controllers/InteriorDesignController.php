<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InteriorDesignController extends Controller
{
    public function index(){
        return 'Welcome to HM. Interior Design';
    }
}
