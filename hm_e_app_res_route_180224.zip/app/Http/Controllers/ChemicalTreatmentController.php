<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ChemicalTreatmentController extends Controller
{
    public function index(){
        return 'Welcome to HM. Chemical Treatment';
    }
}
