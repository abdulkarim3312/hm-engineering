<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class EstimateProductCosting extends Model
{
    protected $guarded =  [];
}
