<?php $__env->startSection('style'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/select2/dist/css/select2.min.css')); ?>">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Requisition
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Requisition Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form method="POST" action="<?php echo e(route('requisition.add')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group <?php echo e($errors->has('project') ? 'has-error' :''); ?>">
                                    <label>Project</label>

                                    <select class="form-control project select2" style="width: 100%;" name="project" id="project">
                                        <option value="">Select Project</option>

                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($project->id); ?>" <?php echo e(old('project') == $project->id ? 'selected' : ''); ?>><?php echo e($project->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>














                            <div class="col-md-4">
                                <div class="form-group <?php echo e($errors->has('date') ? 'has-error' :''); ?>">
                                    <label>Date</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right" id="date" name="date" value="<?php echo e(empty(old('date')) ? ($errors->has('date') ? '' : date('Y-m-d')) : old('date')); ?>" autocomplete="off">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group <?php echo e($errors->has('note') ? 'has-error' :''); ?>">
                                    <label>Note</label>

                                    <div class="form-group">
                                        <input type="text" class="form-control" id="note" name="note" value="<?php echo e(old('note')); ?>">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>Product Name</th>

                                    <th width="15%">Product Unit</th>
                                    <th width="15%">Quantity</th>
                                    <th></th>
                                </tr>
                                </thead>

                                <tbody id="product-container">
                                <?php if(old('product') != null && sizeof(old('product')) > 0): ?>
                                    <?php $__currentLoopData = old('product'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="product-item">
                                            <td>
                                                <div class="form-group <?php echo e($errors->has('product.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <select class="form-control product" style="width: 100%;" name="product[]" required>
                                                        <option value="">Select Product</option>

                                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($product->id); ?>" <?php echo e(old('product.'.$loop->parent->index) == $product->id ? 'selected' : ''); ?>><?php echo e($product->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </td>





                                            <td>
                                                <div class="form-group <?php echo e($errors->has('unit.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text"  name="unit[]" class="form-control unit" value="<?php echo e(old('unit.'.$loop->index)); ?>" readonly>
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('quantity.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="number" class="form-control quantity" name="quantity[]" value="<?php echo e(old('quantity.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td class="text-center">
                                                <a role="button" class="btn btn-danger btn-sm btn-remove">X</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr class="product-item">
                                        <td>
                                            <div class="form-group">
                                                <select class="form-control product" style="width: 100%;" name="product[]" required>
                                                    <option value="">Select Product</option>

                                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </td>






                                        <td>
                                            <div class="form-group">
                                                <input type="text" name="unit[]" class="form-control unit" readonly>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="number" class="form-control quantity" name="quantity[]">
                                            </div>
                                        </td>

                                        <td class="text-center">
                                            <a role="button" class="btn btn-danger btn-sm btn-remove">X</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>

                                <tfoot>
                                <tr>
                                    <td>
                                        <a role="button" class="btn btn-info btn-sm" id="btn-add-product">Add More</a>
                                    </td>



                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <template id="template-product">
        <tr class="product-item">
            <td>
                <div class="form-group">
                    <select class="form-control product" style="width: 100%;" name="product[]" required>
                        <option value="">Select Product</option>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </td>





            <td>
                <div class="form-group">
                    <input type="text" name="unit[]" class="form-control unit" readonly>
                </div>
            </td>
            <td>
                <div class="form-group">
                    <input type="number" class="form-control quantity" name="quantity[]">
                </div>
            </td>

            <td class="text-center">
                <a role="button" class="btn btn-danger btn-sm btn-remove">X</a>
            </td>
        </tr>
    </template>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('themes/backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2();

            //Date picker
            $('#date').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
            var selectedSegment = '<?php echo e(old('segment')); ?>';

            $('body').on('change', '#project', function () {
                var projectId = $(this).val();
                $('#segment').html('<option value="">Select Segment</option>');

                if (projectId != '') {
                    $.ajax({
                        method: "GET",
                        url: "<?php echo e(route('get_segment')); ?>",
                        data: { projectId: projectId }
                    }).done(function( response ) {
                        $.each(response, function( index, item ) {
                            if (selectedSegment == item.id)
                                $('#segment').append('<option value="'+item.id+'" selected>'+item.name+'</option>');
                            else
                                $('#segment').append('<option value="'+item.id+'">'+item.name+'</option>');
                        });
                    });
                }
            });
            $('#project').trigger('change');


            $('#btn-add-product').click(function () {
                var html = $('#template-product').html();
                var item = $(html);

                $('#product-container').append(item);

                initProduct();

                if ($('.product-item').length >= 1 ) {
                    $('.btn-remove').show();
                }
            });

            $('body').on('click', '.btn-remove', function () {
                $(this).closest('.product-item').remove();
                calculate();

                if ($('.product-item').length <= 1 ) {
                    $('.btn-remove').hide();
                }
            });

            $('body').on('keyup', '.quantity', function () {
                calculate();
            });

            if ($('.product-item').length <= 1 ) {
                $('.btn-remove').hide();
            } else {
                $('.btn-remove').show();
            }

            initProduct();
            calculate();
        });

        function calculate() {
            var total = 0;

            $('.product-item').each(function(i, obj) {
                var quantity = $('.quantity:eq('+i+')').val();
                var unit_price = $('.unit:eq('+i+')').val();

                if (quantity == '' || quantity < 0 || !$.isNumeric(quantity))
                    quantity = 0;

                //$('.total-cost:eq('+i+')').html('৳ ' + parseFloat(quantity ).toFixed(2));
                total += parseFloat(quantity);
            });

            $('#total-quantity').html('৳ ' + total.toFixed(2));
        }

        $('body').on('change', '.product', function () {
            var productId = $(this).val();
            //var projectId = $('#project').val();
            //var segmentId = $('#segment').val();
            var itemProduct = $(this);

            itemProduct.closest('tr').find('.available').val(0);
            // var selectedProduct = itemCategory.closest('tr').find('.product').attr("data-selected-product");
            if (productId != '') {
                $.ajax({
                    method: "GET",
                    url: "<?php echo e(route('requisition_product.json')); ?>",
                    data: {
                        productId: productId,
                        //projectId: projectId,
                        //segmentId: segmentId
                    }
                }).done(function (response) {

                    itemProduct.closest('tr').find('.unit').val(response.unit);
                    //itemProduct.closest('tr').find('.available').val(response.available);
                    //itemProduct.closest('tr').find('.quantity').attr('max',response.available);
                });
            }
        });

        $('.product').trigger('change');

        function initProduct() {
            $('.product').select2();
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hm_engineering\resources\views/requisition/create_requisition/create.blade.php ENDPATH**/ ?>