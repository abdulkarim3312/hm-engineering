<?php $__env->startSection('style'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/select2/dist/css/select2.min.css')); ?>">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Beam Configure
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Beam Configure Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form method="POST" action="<?php echo e(route('beam_configure.add')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('estimate_project') ? 'has-error' :''); ?>">
                                    <label>Estimate Projects</label>

                                    <select class="form-control select2" style="width: 100%;" id="estimate_project" name="estimate_project" data-placeholder="Select Estimating Project">
                                        <option value="">Select Estimating Project</option>
                                        <?php $__currentLoopData = $estimateProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimateProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($estimateProject->id); ?>" <?php echo e(old('estimate_project') == $estimateProject->id ? 'selected' : ''); ?>><?php echo e($estimateProject->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['estimate_project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('estimate_floor') ? 'has-error' :''); ?>">
                                    <label>Estimate Floor</label>

                                    <select class="form-control select2" style="width: 100%;" name="estimate_floor" id="estimate_floor" data-placeholder="Select Estimate Floor">
                                        <option value="">Select Estimate Floor</option>
                                    </select>

                                    <?php $__errorArgs = ['estimate_floor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('beam_type') ? 'has-error' :''); ?>">
                                    <label>Beam Type</label>

                                    <select class="form-control select2" style="width: 100%;" name="beam_type" data-placeholder="Select Beam Type">
                                        <option value="">Select Beam Type</option>
                                        <?php $__currentLoopData = $beamTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beamType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($beamType->id); ?>" <?php echo e(old('beam_type') == $beamType->id ? 'selected' : ''); ?>><?php echo e($beamType->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['beam_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('course_aggregate_type') ? 'has-error' :''); ?>">
                                    <label>Course Aggregate Type</label>

                                    <select class="form-control select2" style="width: 100%;" name="course_aggregate_type" id="course_aggregate_type"
                                            data-placeholder="Select Course Aggregate Type">

                                        <option value="1" <?php echo e(old('course_aggregate_type') == 1 ? 'selected' : ''); ?>>Stone</option>
                                        <option value="2" <?php echo e(old('course_aggregate_type') == 2 ? 'selected' : ''); ?>>Brick Chips</option>
                                    </select>

                                    <?php $__errorArgs = ['course_aggregate_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('tie_bar') ? 'has-error' :''); ?>">
                                    <label>Stirrup(Rft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="tie_bar" step="any"
                                               name="tie_bar" value="<?php echo e(old('tie_bar')); ?>" placeholder="Stirrup" readonly>
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['tie_bar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('tie_interval') ? 'has-error' :''); ?>">
                                    <label>Stirrup Interval(Ft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="tie_interval" step="any"
                                               name="tie_interval" value="<?php echo e(old('tie_interval')); ?>" placeholder="Stirrup Interval">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['tie_interval'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('beam_quantity') ? 'has-error' :''); ?>">
                                    <label>Beam Quantity</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="beam_quantity" step="any"
                                               name="beam_quantity" value="<?php echo e(old('beam_quantity')); ?>" placeholder="Beam Quantity">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['beam_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-1">
                                <div class="form-group <?php echo e($errors->has('first_ratio') ? 'has-error' :''); ?>">
                                    <label>Ratio</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="first_ratio" step="any"
                                               name="first_ratio" value="<?php echo e(old('first_ratio')); ?>" placeholder="First(R)">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['first_ratio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-1">
                                <div class="form-group <?php echo e($errors->has('second_ratio') ? 'has-error' :''); ?>">
                                    <label>Ratio</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="second_ratio" step="any"
                                               name="second_ratio" value="<?php echo e(old('second_ratio')); ?>" placeholder="Second(S)">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['second_ratio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-1">
                                <div class="form-group <?php echo e($errors->has('third_ratio') ? 'has-error' :''); ?>">
                                    <label>Ratio</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="third_ratio" step="any"
                                               name="third_ratio" value="<?php echo e(old('third_ratio')); ?>" placeholder="Third(Th)">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['third_ratio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('beam_length') ? 'has-error' :''); ?>">
                                    <label>Beam Length(Ft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="beam_length" step="any"
                                               name="beam_length" value="<?php echo e(old('beam_length')); ?>" placeholder="Beam Length">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['beam_length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('tie_length') ? 'has-error' :''); ?>">
                                    <label>Stirrup Length(Ft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="tie_length" step="any"
                                               name="tie_length" value="<?php echo e(old('tie_length')); ?>" placeholder="Stirrup Length">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['tie_length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('tie_width') ? 'has-error' :''); ?>">
                                    <label>Stirrup Width(Ft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="tie_width" step="any"
                                               name="tie_width" value="<?php echo e(old('tie_width')); ?>" placeholder="Stirrup Width">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['tie_width'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('cover') ? 'has-error' :''); ?>">
                                    <label>Clear Cover(Ft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="cover" step="any"
                                               name="cover" value="<?php echo e(old('cover')); ?>" placeholder="Clear Cover">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('total_volume') ? 'has-error' :''); ?>">
                                    <label>Total Volume(Cft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="total_volume" readonly step="any"
                                               name="total_volume" value="<?php echo e(old('total_volume')); ?>" placeholder="Total Volume">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['total_volume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('dry_volume') ? 'has-error' :''); ?>">
                                    <label>Dry Volume(Cft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="dry_volume" step="any"
                                               name="dry_volume" value="1.5" placeholder="Enter Dry Volume">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['dry_volume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('total_dry_volume') ? 'has-error' :''); ?>">
                                    <label>Total Dry Volume(Cft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" id="total_dry_volume" readonly step="any"
                                               name="total_dry_volume" value="<?php echo e(old('total_dry_volume')); ?>" placeholder="Total Dry Volume">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['total_dry_volume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-5">
                                <div class="form-group <?php echo e($errors->has('date') ? 'has-error' :''); ?>">
                                    <label>Date</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right" id="date" name="date" value="<?php echo e(empty(old('date')) ? ($errors->has('date') ? '' : date('Y-m-d')) : old('date')); ?>" autocomplete="off">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group <?php echo e($errors->has('note') ? 'has-error' :''); ?>">
                                    <label>Note</label>

                                    <div class="form-group">
                                        <input type="text" class="form-control" id="note" name="note" value="<?php echo e(old('note')); ?>">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <u><i><h3>Costing Area</h3></i></u>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('beam_bar_costing') ? 'has-error' :''); ?>">
                                    <label>Bar Cost(Per Kg)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" step="any"
                                               name="beam_bar_costing" value="<?php echo e($pileCost->pile_bar_per_cost??0); ?>" placeholder="Enter Per Kg Bar Costing">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['beam_bar_costing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('beam_cement_costing') ? 'has-error' :''); ?>">
                                    <label>Cement Cost(Per Bag)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" step="any" value="<?php echo e($pileCost->pile_cement_per_cost??0); ?>"
                                               name="beam_cement_costing"  placeholder="Enter Per Bag Cement Costing"
                                        >
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['beam_cement_costing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group <?php echo e($errors->has('beam_sands_costing') ? 'has-error' :''); ?>">
                                    <label>Sands Cost(Per Cft)</label>

                                    <div class="form-group">
                                        <input type="number" class="form-control" step="any" value="<?php echo e($pileCost->pile_sands_per_cost??0); ?>"
                                               name="beam_sands_costing"  placeholder="Enter Per Cft Sands Costing">
                                    </div>
                                    <!-- /.input group -->

                                    <?php $__errorArgs = ['beam_sands_costing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div id="beam_aggregate_costing">
                                <div class="col-md-2">
                                    <div class="form-group <?php echo e($errors->has('beam_aggregate_costing') ? 'has-error' :''); ?>">
                                        <label>Aggregate Cost(Cft)</label>

                                        <div class="form-group">
                                            <input type="number" class="form-control" step="any" value="<?php echo e($pileCost->pile_aggregate_per_cost??0); ?>"
                                                   name="beam_aggregate_costing"  placeholder="Enter Per Cft Aggregates Costing">
                                        </div>
                                        <!-- /.input group -->

                                        <?php $__errorArgs = ['beam_aggregate_costing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div id="beam_picked_costing">
                                <div class="col-md-2">
                                    <div class="form-group <?php echo e($errors->has('beam_picked_costing') ? 'has-error' :''); ?>">
                                        <label>Picked Cost(Per Cft)</label>

                                        <div class="form-group">
                                            <input type="number" class="form-control" step="any" value="<?php echo e($pileCost->pile_picked_per_cost??0); ?>"
                                                   name="beam_picked_costing"  placeholder="Enter Per Pcs Picked Costing">
                                        </div>
                                        <!-- /.input group -->

                                        <?php $__errorArgs = ['beam_picked_costing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <strong><h3>Calculation of Main Bar</h3></strong>
                            <table class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th width="15%">Bar Type</th>
                                    <th width="10%">Dia</th>
                                    <th width="10%">Dia Square(D^2)</th>
                                    <th width="10%">Value of Bar</th>
                                    <th width="10%">Kg/Rft</th>
                                    <th width="10%">Kg/Ton</th>
                                    <th width="10%">Bar Nos.</th>
                                    <th width="10%">Lapping Length</th>
                                    <th width="10%">Lapping Nos.</th>
                                    <th width="10%">Kg</th>
                                    <th width="10%">Ton</th>
                                    <th></th>
                                </tr>
                                </thead>

                                <tbody id="product-container">
                                <?php if(old('product') != null && sizeof(old('product')) > 0): ?>
                                    <?php $__currentLoopData = old('product'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="product-item">
                                            <td>
                                                <div class="form-group <?php echo e($errors->has('product.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <select class="form-control select2 product" style="width: 100%;" name="product[]" data-placeholder="Select Product" required>
                                                            <option value="6" <?php echo e(old('product') == 6 ? 'selected' : ''); ?>>6mm</option>
                                                            <option value="8" <?php echo e(old('product') == 8 ? 'selected' : ''); ?>>8mm</option>
                                                            <option value="10" <?php echo e(old('product') == 10 ? 'selected' : ''); ?>>10mm</option>
                                                            <option value="12" <?php echo e(old('product') == 12 ? 'selected' : ''); ?>>12mm</option>
                                                            <option value="16" <?php echo e(old('product') == 16 ? 'selected' : ''); ?>>16mm</option>
                                                            <option value="18" <?php echo e(old('product') == 18 ? 'selected' : ''); ?>>18mm</option>
                                                            <option value="20" <?php echo e(old('product') == 20 ? 'selected' : ''); ?>>20mm</option>
                                                            <option value="22" <?php echo e(old('product') == 22 ? 'selected' : ''); ?>>22mm</option>
                                                            <option value="25" <?php echo e(old('product') == 25 ? 'selected' : ''); ?>>25mm</option>
                                                            <option value="28" <?php echo e(old('product') == 28 ? 'selected' : ''); ?>>28mm</option>
                                                            <option value="32" <?php echo e(old('product') == 32 ? 'selected' : ''); ?>>32mm</option>
                                                            <option value="36" <?php echo e(old('product') == 36 ? 'selected' : ''); ?>>36mm</option>
                                                    </select>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group <?php echo e($errors->has('dia.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text"  name="dia[]" class="form-control dia" value="<?php echo e(old('dia.'.$loop->index)); ?>" readonly>
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('dia_square.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text" class="form-control dia_square" name="dia_square[]" value="<?php echo e(old('dia_square.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('value_of_bar.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text" readonly class="form-control value_of_bar" name="value_of_bar[]" value="<?php echo e(old('value_of_bar.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('kg_by_rft.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text" class="form-control kg_by_rft" name="kg_by_rft[]" value="<?php echo e(old('kg_by_rft.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('kg_by_ton.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text" readonly class="form-control kg_by_ton" name="kg_by_ton[]" value="<?php echo e(old('kg_by_ton.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('number_of_bar.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="number" class="form-control number_of_bar" name="number_of_bar[]" value="<?php echo e(old('number_of_bar.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('lapping_length.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="number" step="any" class="form-control lapping_length" name="lapping_length[]" value="<?php echo e(old('lapping_length.'.$loop->index)); ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group <?php echo e($errors->has('lapping_nos.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="number" step="any" class="form-control lapping_nos" name="lapping_nos[]" value="<?php echo e(old('lapping_nos.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td class="total-kg">0.00</td>
                                            <td class="total-ton">0.00</td>







                                            <td class="text-center">
                                                <a role="button" class="btn btn-danger btn-sm btn-remove">X</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr class="product-item">
                                        <td>
                                            <div class="form-group">
                                                <select class="form-control product" style="width: 100%;" name="product[]" required>
                                                    <option value="6">6mm</option>
                                                    <option value="8">8mm</option>
                                                    <option value="10">10mm</option>
                                                    <option value="12">12mm</option>
                                                    <option value="16">16mm</option>
                                                    <option value="18">18mm</option>
                                                    <option value="20">20mm</option>
                                                    <option value="22">22mm</option>
                                                    <option value="25">25mm</option>
                                                    <option value="28">28mm</option>
                                                    <option value="32">32mm</option>
                                                    <option value="36">36mm</option>
                                                </select>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" name="dia[]" class="form-control dia" readonly>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" class="form-control dia_square" name="dia_square[]">
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" readonly class="form-control value_of_bar" name="value_of_bar[]" value="532.17">
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" class="form-control kg_by_rft" name="kg_by_rft[]">
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" readonly class="form-control kg_by_ton" name="kg_by_ton[]" value="1000">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input type="number" class="form-control number_of_bar" name="number_of_bar[]">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input type="number" step="any" class="form-control lapping_length" name="lapping_length[]">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input type="number" step="any" class="form-control lapping_nos" name="lapping_nos[]">
                                            </div>
                                        </td>
                                        <td class="total-kg">0.00</td>
                                        <td class="total-ton">0.00</td>








                                        <td class="text-center">
                                            <a role="button" class="btn btn-danger btn-sm btn-remove">X</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>

                                <tfoot>
                                <tr>
                                    <td>
                                        <a role="button" class="btn btn-info btn-sm" id="btn-add-product">Add More</a>
                                    </td>



                                </tr>
                                </tfoot>
                            </table>
                        </div>

                        <div class="table-responsive">
                            <strong><h3>Calculation of Extra Bar</h3></strong>
                            <table class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th width="15%">Bar Type</th>
                                    <th width="10%">Dia</th>
                                    <th width="10%">Dia Square(D^2)</th>
                                    <th width="10%">Value of Bar</th>
                                    <th width="10%">Kg/Rft</th>
                                    <th width="10%">Kg/Ton</th>
                                    <th width="10%">Bar Nos.</th>
                                    <th width="10%">Length</th>
                                    <th>Kg</th>
                                    <th>Ton</th>
                                    <th></th>
                                </tr>
                                </thead>

                                <tbody id="extra-container">
                                <?php if(old('extra_product') != null && sizeof(old('extra_product')) > 0): ?>
                                    <?php $__currentLoopData = old('extra_product'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="extra-item">
                                            <td>
                                                <div class="form-group <?php echo e($errors->has('extra_product.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <select class="form-control select2 extra_product" name="extra_product[]" data-placeholder="Select Product" required>
                                                        <option value="6" <?php echo e(old('extra_product') == 6 ? 'selected' : ''); ?>>6mm</option>
                                                        <option value="8" <?php echo e(old('extra_product') == 8 ? 'selected' : ''); ?>>8mm</option>
                                                        <option value="10" <?php echo e(old('extra_product') == 10 ? 'selected' : ''); ?>>10mm</option>
                                                        <option value="12" <?php echo e(old('extra_product') == 12 ? 'selected' : ''); ?>>12mm</option>
                                                        <option value="16" <?php echo e(old('extra_product') == 16 ? 'selected' : ''); ?>>16mm</option>
                                                        <option value="18" <?php echo e(old('extra_product') == 18 ? 'selected' : ''); ?>>18mm</option>
                                                        <option value="20" <?php echo e(old('extra_product') == 20 ? 'selected' : ''); ?>>20mm</option>
                                                        <option value="22" <?php echo e(old('extra_product') == 22 ? 'selected' : ''); ?>>22mm</option>
                                                        <option value="25" <?php echo e(old('extra_product') == 25 ? 'selected' : ''); ?>>25mm</option>
                                                        <option value="28" <?php echo e(old('extra_product') == 28 ? 'selected' : ''); ?>>28mm</option>
                                                        <option value="32" <?php echo e(old('extra_product') == 32 ? 'selected' : ''); ?>>32mm</option>
                                                        <option value="36" <?php echo e(old('extra_product') == 36 ? 'selected' : ''); ?>>36mm</option>
                                                    </select>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group <?php echo e($errors->has('extra_dia.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text"  name="extra_dia[]" class="form-control extra_dia" value="<?php echo e(old('extra_dia.'.$loop->index)); ?>" readonly>
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('extra_dia_square.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text" class="form-control extra_dia_square" name="extra_dia_square[]" value="<?php echo e(old('extra_dia_square.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('extra_value_of_bar.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text" readonly class="form-control extra_value_of_bar" name="extra_value_of_bar[]" value="<?php echo e(old('extra_value_of_bar.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('extra_kg_by_rft.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text" class="form-control extra_kg_by_rft" name="extra_kg_by_rft[]" value="<?php echo e(old('extra_kg_by_rft.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('extra_kg_by_ton.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="text" readonly class="form-control extra_kg_by_ton" name="extra_kg_by_ton[]" value="<?php echo e(old('extra_kg_by_ton.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('extra_number_of_bar.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="number" class="form-control extra_number_of_bar" name="extra_number_of_bar[]" value="<?php echo e(old('extra_number_of_bar.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td>
                                                <div class="form-group <?php echo e($errors->has('extra_length.'.$loop->index) ? 'has-error' :''); ?>">
                                                    <input type="number"  step="any" class="form-control extra_length" name="extra_length[]" value="<?php echo e(old('extra_length.'.$loop->index)); ?>">
                                                </div>
                                            </td>

                                            <td class="extra-total-kg">0.00</td>
                                            <td class="extra-total-ton">0.00</td>
                                            <td class="text-center">
                                                <a role="button" class="btn btn-danger btn-sm extra-btn-remove">X</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr class="extra-item">
                                        <td>
                                            <div class="form-group">
                                                <select class="form-control extra_product" style="width: 100%;" name="extra_product[]" required>
                                                    <option value="6">6mm</option>
                                                    <option value="8">8mm</option>
                                                    <option value="10">10mm</option>
                                                    <option value="12">12mm</option>
                                                    <option value="16">16mm</option>
                                                    <option value="18">18mm</option>
                                                    <option value="20">20mm</option>
                                                    <option value="22">22mm</option>
                                                    <option value="25">25mm</option>
                                                    <option value="28">28mm</option>
                                                    <option value="32">32mm</option>
                                                    <option value="36">36mm</option>
                                                </select>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" name="extra_dia[]" class="form-control extra_dia" readonly>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" class="form-control extra_dia_square" name="extra_dia_square[]">
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" readonly class="form-control extra_value_of_bar" name="extra_value_of_bar[]" value="532.17">
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" class="form-control extra_kg_by_rft" name="extra_kg_by_rft[]">
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="text" readonly class="form-control extra_kg_by_ton" name="extra_kg_by_ton[]" value="1000">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input type="number" class="form-control extra_number_of_bar" name="extra_number_of_bar[]" value="0">
                                            </div>
                                        </td>

                                        <td>
                                            <div class="form-group">
                                                <input type="number"  step="any" class="form-control extra_length" name="extra_length[]" value="0">
                                            </div>
                                        </td>
                                        <td class="extra-total-kg">0.00</td>
                                        <td class="extra-total-ton">0.00</td>

                                        <td class="text-center">
                                            <a role="button" class="btn btn-danger btn-sm extra-btn-remove">X</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>

                                <tfoot>
                                <tr>
                                    <td>
                                        <a role="button" class="btn btn-info btn-sm" id="btn-add-extra-product">Add More</a>
                                    </td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <template id="template-product">
        <tr class="product-item">
            <td>
                <div class="form-group">
                    <select class="form-control product" style="width: 100%;" name="product[]" required>
                        <option value="6">6mm</option>
                        <option value="8">8mm</option>
                        <option value="10">10mm</option>
                        <option value="12">12mm</option>
                        <option value="16">16mm</option>
                        <option value="18">18mm</option>
                        <option value="20">20mm</option>
                        <option value="22">22mm</option>
                        <option value="25">25mm</option>
                        <option value="28">28mm</option>
                        <option value="32">32mm</option>
                        <option value="36">36mm</option>
                    </select>
                </div>
            </td>
            <td>
                <div class="form-group">
                    <input type="text" name="dia[]" class="form-control dia" readonly>
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" class="form-control dia_square" name="dia_square[]">
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" readonly class="form-control value_of_bar" name="value_of_bar[]" value="532.17">
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" class="form-control kg_by_rft" name="kg_by_rft[]">
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" readonly class="form-control kg_by_ton" name="kg_by_ton[]" value="1000">
                </div>
            </td>
            <td>
                <div class="form-group">
                    <input type="number" class="form-control number_of_bar" name="number_of_bar[]">
                </div>
            </td>
            <td>
                <div class="form-group">
                    <input type="number" step="any" class="form-control lapping_length" name="lapping_length[]">
                </div>
            </td>
            <td>
                <div class="form-group">
                    <input type="number" step="any" class="form-control lapping_nos" name="lapping_nos[]">
                </div>
            </td>
            <td class="total-kg">0.00</td>
            <td class="total-ton">0.00</td>







            <td class="text-center">
                <a role="button" class="btn btn-danger btn-sm btn-remove">X</a>
            </td>
        </tr>
    </template>
    <template id="template-extra-product">
        <tr class="extra-item">
            <td>
                <div class="form-group">
                    <select class="form-control extra_product" style="width: 100%;" name="extra_product[]" required>
                        <option value="6">6mm</option>
                        <option value="8">8mm</option>
                        <option value="10">10mm</option>
                        <option value="12">12mm</option>
                        <option value="16">16mm</option>
                        <option value="18">18mm</option>
                        <option value="20">20mm</option>
                        <option value="22">22mm</option>
                        <option value="25">25mm</option>
                        <option value="28">28mm</option>
                        <option value="32">32mm</option>
                        <option value="36">36mm</option>
                    </select>
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" name="extra_dia[]" class="form-control extra_dia" readonly>
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" class="form-control extra_dia_square" name="extra_dia_square[]">
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" readonly class="form-control extra_value_of_bar" name="extra_value_of_bar[]" value="532.17">
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" class="form-control extra_kg_by_rft" name="extra_kg_by_rft[]">
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="text" readonly class="form-control extra_kg_by_ton" name="extra_kg_by_ton[]" value="1000">
                </div>
            </td>
            <td>
                <div class="form-group">
                    <input type="number" class="form-control extra_number_of_bar" name="extra_number_of_bar[]" value="0">
                </div>
            </td>

            <td>
                <div class="form-group">
                    <input type="number"  step="any" class="form-control extra_length" name="extra_length[]" value="0">
                </div>
            </td>
            <td class="extra-total-kg">0.00</td>
            <td class="extra-total-ton">0.00</td>

            <td class="text-center">
                <a role="button" class="btn btn-danger btn-sm extra-btn-remove">X</a>
            </td>
        </tr>
    </template>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('themes/backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2();

            //Date picker
            $('#date').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
            $('body').on('change','#course_aggregate_type', function () {
                var courseType = $(this).val();


                if (courseType == 1) {
                    $('#beam_picked_costing').hide();
                    $('#beam_aggregate_costing').show();
                }else if(courseType == 2){
                    $('#beam_picked_costing').show();
                    $('#beam_aggregate_costing').hide();
                }else {

                }
            })
            $('#course_aggregate_type').trigger("change");

            $('#btn-add-product').click(function () {
                var html = $('#template-product').html();
                var item = $(html);

                $('#product-container').append(item);

                initProduct();

                if ($('.product-item').length >= 1 ) {
                    $('.btn-remove').show();
                }
            });

            $('body').on('click', '.btn-remove', function () {
                $(this).closest('.product-item').remove();
                calculate();

                if ($('.product-item').length <= 1 ) {
                    $('.btn-remove').hide();
                }
            });
            $('#btn-add-extra-product').click(function () {
                var html = $('#template-extra-product').html();
                var item = $(html);

                $('#extra-container').append(item);

                initProduct();

                if ($('.extra-item').length >= 1 ) {
                    $('.extra-btn-remove').show();
                }
            });

            $('body').on('click', '.extra-btn-remove', function () {
                $(this).closest('.extra-item').remove();
                calculate();

                if ($('.extra-item').length <= 1 ) {
                    $('.btn-remove').hide();
                }
            });

            var selectedFloor = '<?php echo e(old('estimate_floor')); ?>';

            $('body').on('change', '#estimate_project', function () {
                var estimateProjectId = $(this).val();
                $('#estimate_floor').html('<option value="">Select Estimate Floor</option>');

                if (estimateProjectId != '') {
                    $.ajax({
                        method: "GET",
                        url: "<?php echo e(route('get_estimate_floor')); ?>",
                        data: { estimateProjectId:estimateProjectId }
                    }).done(function( response ) {
                        $.each(response, function( index, item ) {
                            if (selectedFloor == item.id)
                                $('#estimate_floor').append('<option value="'+item.id+'" selected>'+item.name+'</option>');
                            else
                                $('#estimate_floor').append('<option value="'+item.id+'">'+item.name+'</option>');
                        });
                    });
                }
            });
            $('#estimate_project').trigger('change');

            $('body').on('change','.product', function () {
                var productID = $(this).val();
                var itemproductID = $(this);
                var barValue = itemproductID.closest('tr').find('.value_of_bar').val();
                var kgTon = itemproductID.closest('tr').find('.kg_by_ton').val();


                if (productID != '') {
                    itemproductID.closest('tr').find('.dia').val(productID);
                    itemproductID.closest('tr').find('.dia_square').val(productID * productID);
                    itemproductID.closest('tr').find('.kg_by_rft').val(((productID * productID) / barValue).toFixed(2));
                }
            })
            $('.product').trigger("change");

            $('body').on('change','.extra_product', function () {
                var extraProductID = $(this).val();
                var itemProductID = $(this);
                var extraBarValue = itemProductID.closest('tr').find('.extra_value_of_bar').val();


                if (extraProductID != '') {
                    itemProductID.closest('tr').find('.extra_dia').val(extraProductID);
                    itemProductID.closest('tr').find('.extra_dia_square').val(extraProductID * extraProductID);
                    itemProductID.closest('tr').find('.extra_kg_by_rft').val(((extraProductID * extraProductID) / extraBarValue).toFixed(2));
                }
            })
            $('.extra_product').trigger("change");


            $('body').on('keyup','#beam_length,#tie_length,#dry_volume,' +
                '.number_of_bar,#cover,#tie_length,#tie_width,.lapping_length,.lapping_nos', function () {
                calculate();
            });

            $('body').on('keyup','.extra_length,.extra_number_of_bar', function () {
                calculate();
            });

            if ($('.product-item').length <= 1 ) {
                $('.btn-remove').hide();
            } else {
                $('.btn-remove').show();
            }

            initProduct();
            calculate();
        });

        function calculate() {
            var total_volume = 0;
            var beam_length = $('#beam_length').val();
            var dry_volume = $('#dry_volume').val();
            var tie_interval = $('#tie_interval').val();
            var cover = $('#cover').val();
            var tie_length = $('#tie_length').val();
            var tie_width = $('#tie_width').val();

            if (beam_length == '' || beam_length < 0 || !$.isNumeric(beam_length))
                beam_length = 0;

            if (tie_length == '' || tie_length < 0 || !$.isNumeric(tie_length))
                tie_length = 0;

            if (dry_volume == '' || dry_volume < 0 || !$.isNumeric(dry_volume))
                dry_volume = 0;

            if (tie_interval == '' || tie_interval < 0 || !$.isNumeric(tie_interval))
                tie_interval = 0;

            if (cover == '' || cover < 0 || !$.isNumeric(cover))
                cover = 0;

            if (tie_length == '' || tie_length < 0 || !$.isNumeric(tie_length))
                tie_length = 0;

            if (tie_width == '' || tie_width < 0 || !$.isNumeric(tie_width))
                tie_width = 0;

            $('.product-item').each(function(i, obj) {
                var number_of_bar = $('.number_of_bar:eq('+i+')').val();
                var kg_by_ton = $('.kg_by_ton:eq('+i+')').val();
                var kg_by_rft = $('.kg_by_rft:eq('+i+')').val();
                var lapping_length = $('.lapping_length:eq('+i+')').val();
                var lapping_nos = $('.lapping_nos:eq('+i+')').val();

                if (number_of_bar == '' || number_of_bar < 0 || !$.isNumeric(number_of_bar))
                    number_of_bar = 0;

                if (kg_by_ton == '' || kg_by_ton < 0 || !$.isNumeric(kg_by_ton))
                    kg_by_ton = 0;

                if (kg_by_rft == '' || kg_by_rft < 0 || !$.isNumeric(kg_by_rft))
                    kg_by_rft = 0;

                if (beam_length == '' || beam_length < 0 || !$.isNumeric(beam_length))
                    beam_length = 0;

                if (lapping_length == '' || lapping_length < 0 || !$.isNumeric(lapping_length))
                    lapping_length = 0;

                if (lapping_nos == '' || lapping_nos < 0 || !$.isNumeric(lapping_nos))
                    lapping_nos = 0;

                var lappingKg = ((lapping_length * lapping_nos) * kg_by_rft)

                $('.total-kg:eq('+i+')').html(parseFloat(((beam_length * kg_by_rft) * number_of_bar) + lappingKg).toFixed(2));
                $('.total-ton:eq('+i+')').html(parseFloat(((((beam_length * kg_by_rft) * number_of_bar) + lappingKg)/kg_by_ton)).toFixed(3));
                //total += rft_by_ton;
            });

            $('.extra-item').each(function(i, obj) {
                var extra_number_of_bar = $('.extra_number_of_bar:eq('+i+')').val();
                var extra_kg_by_ton = $('.extra_kg_by_ton:eq('+i+')').val();
                var extra_kg_by_rft = $('.extra_kg_by_rft:eq('+i+')').val();
                var extra_length = $('.extra_length:eq('+i+')').val();

                if (extra_number_of_bar == '' || extra_number_of_bar < 0 || !$.isNumeric(extra_number_of_bar))
                    extra_number_of_bar = 0;

                if (extra_kg_by_ton == '' || extra_kg_by_ton < 0 || !$.isNumeric(extra_kg_by_ton))
                    extra_kg_by_ton = 0;

                if (extra_kg_by_rft == '' || extra_kg_by_rft < 0 || !$.isNumeric(extra_kg_by_rft))
                    extra_kg_by_rft = 0;

                if (extra_length == '' || extra_length < 0 || !$.isNumeric(extra_length))
                    extra_length = 0;

                $('.extra-total-kg:eq('+i+')').html(parseFloat((extra_length * extra_kg_by_rft) * extra_number_of_bar).toFixed(2));
                $('.extra-total-ton:eq('+i+')').html(parseFloat((((extra_length * extra_kg_by_rft) * extra_number_of_bar)/extra_kg_by_ton)).toFixed(3));
            });

            total_volume = beam_length * tie_width * tie_length ;

            var width_tie = tie_width - (2 * cover);
            var length_tie = tie_length - (2 * cover);

            var interval = ((beam_length / tie_interval) + 1);

            var pre_tie_bar = ((width_tie + length_tie) * 2) + 0.42;


            $('#total_volume').val(total_volume.toFixed(2));
            $('#total_dry_volume').val((total_volume * dry_volume).toFixed(2));
            $('#tie_bar').val((interval * pre_tie_bar).toFixed(2));

            //$('#total-ton').html(total);
        }

        function initProduct() {
            $('.product').select2();
            //$('.extra_product').select2();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hm_engineering\resources\views/estimate/beam_configure/add.blade.php ENDPATH**/ ?>