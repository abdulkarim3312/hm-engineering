<?php $__env->startSection('style'); ?>

    <style>
        .img-overlay {
            position: absolute;
            left: 0;
            top: 150px;
            width: 100%;
            height: 100%;
            overflow: hidden;
            text-align: center;
            z-index: 9;
            opacity: 0.2;
        }

        .img-overlay img {
            width: 400px;
            height: auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Sale Inventory View Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Filter</h3>
                </div>
                <!-- /.box-header -->

                <div class="box-body">
                    <form action="<?php echo e(route('sale_inventory.floor_wise_view')); ?>">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Project</label>
                                    <select class="form-control" name="project" required>
                                        <option value="">Select Project</option>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(request()->get('project') == $project->project_id ? 'selected' : ''); ?> value="<?php echo e($project->project_id); ?>"><?php echo e($project->project->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>	&nbsp;</label>
                                    <input class="btn btn-primary form-control" type="submit" value="Submit">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12" style="min-height:300px">
            <?php if($floorWiseProjects): ?>
                <section class="panel">

                    <div class="panel-body">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea')">Print</button><br><hr>

                        <div class="adv-table" id="prinarea">
                            <div class="row">
                                <div class="col-xs-4 text-left">
                                    <img style="width: 35%;margin-top: 20px" src="<?php echo e(asset('img/head_logo.jpeg')); ?>">
                                </div>
                                <div class="col-xs-8 text-left">
                                    <div style="padding:10px; width:100%; text-align:center;">
                                        <h2><?php echo e(\App\Enumeration\Text::$companyName); ?></h2>
                                        <h4><?php echo e(\App\Enumeration\Text::$companyAddress); ?></h4>
                                        <h4><?php echo e(\App\Enumeration\Text::$companyMobileNumber); ?></h4>
                                        <h4><?php echo e(\App\Enumeration\Text::$companyEmail); ?></h4>
                                    </div>
                                </div>
                                <div class="col-xs-12 text-left">
                                    <h4><strong>Receipt</strong></h4>
                                </div>
                            </div>
                            <table class="table table-bordered" style="margin-bottom: 0px">
                                <tr>
                                    <th class="text-center"><?php echo e($projectName->project->name); ?></th>
                            </table>

                            <div style="clear: both">
                                <div class="img-overlay">
                                    <img src="<?php echo e(asset('img/logo.png')); ?>">
                                </div>

                                <table class="table table-bordered" style="width:100%; float:left">
                                    <?php $__currentLoopData = $floorWiseProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $floorWiseProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th class="text-left"><?php echo e($floorWiseProject->floor->name); ?></th>

                                            <?php $__currentLoopData = $floorWiseProject->floor->flat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th class="text-left flat-item">
                                                    <?php echo e($item->name); ?>

                                                    <?php if(count($item->saleOrders) > 0): ?>
                                                        <?php $__currentLoopData = $item->saleOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $saleOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($saleOrder->flat_id == $item->id): ?>
                                                                (<?php echo e($saleOrder->client->name??''); ?>)(<span class="label label-danger">Sold</span>)
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <span class="label label-success">Available</span>
                                                    <?php endif; ?>

                                                </th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>

                            </div>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            //Date picker
            $('#start, #end').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
        });
        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(print) {

            $('body').html($('#'+print).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hm_engineering\resources\views/sale/inventory/floor_wise_view.blade.php ENDPATH**/ ?>