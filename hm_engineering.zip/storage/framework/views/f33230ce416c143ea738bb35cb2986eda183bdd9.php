<?php $__env->startSection('title'); ?>
<?php echo e($receiptPayment->payment_type == 1 ? 'Cheque' : 'Cash'); ?> Receipt No:<?php echo e($receiptPayment->receipt_payment_no); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>

        table,.table,table td,

        .table-bordered{
            border: 1px solid #000000;
        }
        .table-bordered td, .table-bordered th {
            border: 1px solid #000000 !important;
        }
        .table.body-table td,.table.body-table th {
            padding: 2px 7px;
        }
        ul.document-list {margin: 0;padding: 0;list-style: auto;}

        ul.document-list li {display: inline-block;}
        .row {
            margin-right: 0;
            margin-left: 0;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row">
       <div class="col-md-12">
           <div class="box">
               <div class="box-header">
                   <a target="_blank" class="btn btn-default btn-lg" href="<?php echo e(route('receipt_print',['receiptPayment'=>$receiptPayment->id])); ?>"><i class="fa fa-print"></i></a>
               </div>
               <div class="box-body">
                   <div class="row">
                       <div class="col-12">
                           <h1 class="text-center m-0" style="font-size: 35px !important;font-weight: bold">
                               <img height="80px" src="<?php echo e(asset('img/logo.png')); ?>" alt="">
                               <?php echo e(config('app.name')); ?>

                           </h1>
                           <h3 class="text-center m-0" style="font-size: 22px !important;"><?php echo e($receiptPayment->payment_type == 1 ? 'Cheque' : 'Cash'); ?> Receipt</h3>
                           <h3 class="text-center m-0 fs-style" style="font-size: 22px !important;">FY : <?php echo e($receiptPayment->financial_year); ?></h3>
                       </div>
                   </div>
                   <div class="row" style="margin-top: 10px;">
                       <div class="col-xs-4 col-xs-offset-8">
                           <h4 style="margin: 0;font-size: 20px!important;">Receipt No: <?php echo e($receiptPayment->receipt_payment_no); ?></h4>
                           <h4 style="margin: 0;font-size: 20px!important;">Date: <?php echo e($receiptPayment->date->format('d-m-Y')); ?></h4>
                       </div>
                   </div>
                   <div class="row" style="margin-top: 10px;">
                       <div class="col-12">
                           <table class="table table-bordered">
                               <tr>
                                   <th width="24%">Depositor's Name & Designation</th>
                                   <th width="2%" class="text-center">:</th>
                                   <td width=""><?php echo e($receiptPayment->client->name ?? ''); ?> <?php echo e($receiptPayment->client->designation ?? ''); ?></td>
                                   <td><b>ID:</b> <?php echo e($receiptPayment->customer_id); ?></td>
                               </tr>
                               <tr>
                                   <th width="24%">Address</th>
                                   <th width="2%" class="text-center">:</th>
                                   <td width=""><?php echo e($receiptPayment->client->address ?? ''); ?></td>
                                   <td><b>Project Name:</b> <?php echo e($receiptPayment->project->name ??''); ?></td>
                               </tr>
                               <tr>
                                    <th width="24%">Payment Step</th>
                                    <th width="2%" class="text-center">:</th>
                                        <?php if($receiptPayment->payment_step == 1): ?>
                                            <td width="">Booking Money</td>
                                        <?php elseif($receiptPayment->payment_step == 2): ?>
                                            <td width="">Down Payment</td>
                                        <?php elseif($receiptPayment->payment_step == 3): ?>
                                            <td width=""><?php echo e($receiptPayment->installment_name ?? ''); ?></td>
                                        <?php else: ?>
                                            <td width=""></td>
                                        <?php endif; ?>
                                    
                                </tr>
                               <?php if($receiptPayment->payment_type == 1): ?>
                               <tr>
                                   <th width="24%">Issuing Bank</th>
                                   <th width="2%" class="text-center">:</th>
                                   <td width="" colspan="2"><?php echo e($receiptPayment->issuing_bank_name.',' ?? ''); ?> <?php echo e($receiptPayment->issuing_branch_name); ?></td>
                               </tr>
                               <tr>
                                   <th width="24%">Cheque No.</th>
                                   <th width="2%" class="text-center">:</th>
                                   <td width="" ><?php echo e($receiptPayment->cheque_no); ?></td>
                                   <td><b>Cheque Date:</b> <?php echo e($receiptPayment->cheque_date->format('d-m-Y')); ?></td>
                               </tr>
                               <?php endif; ?>
                               <tr>
                                   <th width="24%">Mobile No</th>
                                   <th width="2%" class="text-center">:</th>
                                   <td width=""><?php echo e($receiptPayment->client->mobile_no ?? ''); ?></td>
                                   <td width=""><b>Email:</b> <?php echo e($receiptPayment->client->email ?? ''); ?></td>
                               </tr>
                               <tr>
                                   <th width="24%">Floor Name</th>
                                   <th width="2%" class="text-center">:</th>
                                   <td width=""><?php echo e($receiptPayment->floor->name ?? ''); ?></td>
                                   <td width=""><b>Flat Name:</b> <?php echo e($receiptPayment->flat->name ?? ''); ?></td>
                               </tr>
                           </table>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-12">
                           <span style="font-size: 22px !important;"><b>Received Details:</b></span>
                           <table class="table body-table table-bordered">
                               <tr>
                                   <th  class="text-center" width="50%">Brief Description</th>
                                   <th class="text-center">Account Code</th>
                                   <th class="text-center"></th>
                                   <th class="text-center">Amount(TK)</th>
                               </tr>

                               <tr>
                                   <td style="border-bottom: 1px solid transparent !important;"><b>Received:</b></td>
                                   <td class="text-center" style="border-bottom: 1px solid transparent !important;"></td>
                                   <td style="border-bottom: 1px solid transparent !important;"></td>
                                   <td style="border-bottom: 1px solid transparent !important;" class="text-right"></td>
                               </tr>
                               <?php $__currentLoopData = $receiptPayment->receiptPaymentDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $receiptPaymentDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                   <tr>
                                       <td style="border-bottom: 1px solid transparent !important;">
                                           <?php echo e($receiptPaymentDetail->accountHead->name); ?>

                                           <?php if($receiptPaymentDetail->narration): ?>
                                               (<?php echo e($receiptPaymentDetail->narration); ?>)
                                           <?php endif; ?>
                                       </td>
                                       <td style="border-bottom: 1px solid transparent !important;" class="text-center"><?php echo e($receiptPaymentDetail->accountHead->account_code); ?></td>
                                       <td style="<?php echo e(count($receiptPayment->receiptPaymentDetails) == $key + 1 ? 'border-bottom: 1px solid #000 !important' : 'border-bottom: 1px solid transparent !important'); ?>;"></td>
                                       <td style="<?php echo e(count($receiptPayment->receiptPaymentDetails) == $key + 1 ? 'border-bottom: 1px solid #000 !important' : 'border-bottom: 1px solid transparent !important'); ?>;" class="text-right"><?php echo e(number_format($receiptPaymentDetail->amount,2)); ?></td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               <tr>
                                   <td style="border-bottom: 1px solid #000 !important;"></td>
                                   <td style="border-bottom: 1px solid #000 !important;" class="text-center"></td>
                                   <td class="text-center" style="border-bottom: 1.5px solid #000 !important;">Cr</td>
                                   <th style="border-bottom: 1.5px solid #000 !important;" class="text-right"><?php echo e(number_format($receiptPayment->sub_total,2)); ?></th>
                               </tr>

                               <tr>
                                   <th class="text-left">Total(in word) = <?php echo e($receiptPayment->amount_in_word); ?> Only.</th>
                                   <th class="text-center"></th>
                                   <th class="text-center">Dr.</th>
                                   <th class="text-right"><?php echo e(number_format($receiptPayment->net_amount,2)); ?></th>
                               </tr>
                           </table>
                           <br>
                           <div class="row">
                               <div class="col-md-6">
                                   <p><b>Note:</b> <?php echo e($receiptPayment->notes); ?></p>
                               </div>
                               <?php if(count($receiptPayment->files) > 0): ?>
                                   <div class="col-md-6">
                                       <b>Supporting Documents:</b>
                                       <ul class="document-list">
                                           <?php $__currentLoopData = $receiptPayment->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <li>
                                                   <a target="_blank" class="btn btn-success btn-sm" href="<?php echo e(asset($file->file)); ?>"> Download <i class="fa fa-file-download"></i> </a>
                                               </li>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </ul>

                                   </div>
                               <?php endif; ?>
                           </div>

                       </div>
                   </div>
                   <div class="row signature-area" style="margin-top: 30px">
                       <div class="col-md-3 text-center"><span style="border: 1px solid #000 !important;display: block;padding: 18px;font-size: 20px;font-weight: bold">Prepared By</span></div>
                       <div class="col-md-3 text-center"><span style="border: 1px solid #000 !important;display: block;padding: 18px;font-size: 20px;font-weight: bold">Checked By</span></div>
                       <div class="col-md-3 text-center"><span style="border: 1px solid #000 !important;display: block;padding: 18px;font-size: 20px;font-weight: bold">Approved By</span></div>
                       <div class="col-md-3 text-center"><span style="border: 1px solid #000 !important;display: block;padding: 18px;font-size: 20px;font-weight: bold">Received By</span></div>
                   </div>
               </div>
           </div>
       </div>
   </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hm_engineering\resources\views/accounts/receipt/details.blade.php ENDPATH**/ ?>