<?php $__env->startSection('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Payment Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Payment Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('receipt_details.edit', ['receiptPayment' => $receiptPayment->id])); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">

                        <div class="form-group <?php echo e($errors->has('financial_year') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Select Financial Year *</label>

                            <div class="col-sm-10">
                                <select class="form-control select2" style="width: 100%" name="financial_year" id="financial_year">

                                    <?php for($i=2022; $i <= date('Y'); $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e(old('financial_year',$receiptPayment->financial_year) == $i ? 'selected' : ''); ?>><?php echo e($i); ?>-<?php echo e($i+1); ?></option>
                                    <?php endfor; ?>
                                </select>

                                <?php $__errorArgs = ['financial_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Client Name *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Name"
                                       name="name" value="<?php echo e(empty(old('name')) ? ($errors->has('name') ? '' : $receiptPayment->client->name) : old('name')); ?>">
                                <input type="hidden" name="client_id" value="<?php echo e($receiptPayment->client_id); ?>">

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('order_no') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Select Order No *</label>

                            <div class="col-sm-10">
                                <select class="form-control select2" style="width: 100%" id="modal-order" name="order_no">
                                    <option value="">Select Order</option>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($order->id); ?>" <?php echo e(old('order_no',$receiptPayment->sales_order_id) == $order->id ? 'selected' : ''); ?>><?php echo e($order->order_no); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['order_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div id="modal-order-info" style="background-color: lightgrey; padding: 10px; border-radius: 3px; margin-left: 191px;margin-bottom: 10px;"></div>


                        


                        <div class="form-group <?php echo e($errors->has('payment_type') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Payment Step</label>

                            <div class="col-sm-10">
                                <select id="payment_step_show" name="payment_step"  class="form-control">
                                    <option value="">Select Payment Step</option>
                                    <option value="1" <?php echo e(old('payment_step',$receiptPayment->payment_step) == '1' ? 'selected' : ''); ?>>Boking Money</option>
                                    <option value="2" <?php echo e(old('payment_step',$receiptPayment->payment_step) == '2' ? 'selected' : ''); ?>>Down Payment</option>
                                    <option value="3" <?php echo e(old('payment_step',$receiptPayment->payment_step) == '3' ? 'selected' : ''); ?>>Installment</option>
                                </select>
                                

                                <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group payment-step-show <?php echo e($errors->has('installment_name') ? 'has-error' :''); ?>" style="display: none">
                            <label class="col-sm-2 control-label">Installment Step</label>

                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="installment_name" placeholder="installment step name" value="<?php echo e(empty(old('installment_name')) ? ($errors->has('installment_name') ? '' : $receiptPayment->installment_name) : old('installment_name')); ?>">

                                <?php $__errorArgs = ['installment_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('payment_type') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Payment Type *</label>

                            <div class="col-sm-10">
                                <select class="form-control" id="payment_type" name="payment_type">
                                    <option value="">Select Payment Type</option>
                                    <option value="1" <?php echo e(old('payment_type',$receiptPayment->payment_type) == '1' ? 'selected' : ''); ?>>Cheque</option>
                                    <option value="2" <?php echo e(old('payment_type',$receiptPayment->payment_type) == '2' ? 'selected' : ''); ?>>Cash</option>
                                </select>

                                <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('account') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Cash/Bank Account *</label>

                            <div class="col-sm-10">
                                <select class="form-control select2" id="account" name="account">
                                    <option value=""> Select Cash/Bank Account </option>
                                    <?php $__currentLoopData = $accountHeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountHead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($accountHead->id); ?>" <?php echo e(old('account',$receiptPayment->account_head_id) == $accountHead->id ? 'selected' : ''); ?>>
                                        Account:<?php echo e($accountHead->name); ?>|Account Code:<?php echo e($accountHead->account_code); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group bank-area <?php echo e($errors->has('cheque_no') ? 'has-error' :''); ?>" style="display: none">
                            <label class="col-sm-2 control-label">Cheque No.</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Cheque No"
                                       name="cheque_no" value="<?php echo e(empty(old('cheque_no')) ? ($errors->has('cheque_no') ? '' : $receiptPayment->cheque_no) : old('cheque_no')); ?>">

                                <?php $__errorArgs = ['cheque_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group bank-area <?php echo e($errors->has('cheque_date') ? 'has-error' :''); ?>" style="display: none">
                            <label class="col-sm-2 control-label">Cheque Date</label>

                            <div class="col-sm-10">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" id="cheque_date" name="cheque_date"
                                           value="<?php echo e(empty(old('cheque_date')) ? ($errors->has('cheque_date') ? '' : $receiptPayment->cheque_date) : old('cheque_date')); ?>" autocomplete="off">
                                </div>
                                <!-- /.input group -->

                                <?php $__errorArgs = ['cheque_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group bank-area <?php echo e($errors->has('cheque_image') ? 'has-error' :''); ?>" style="display: none">
                            <label class="col-sm-2 control-label">Cheque image</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="cheque_image" >

                                <?php $__errorArgs = ['cheque_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('amount') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Amount</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control pull-right" id="amount" name="amount"
                                       value="<?php echo e(old('amount',$receiptPayment->net_amount)); ?>" autocomplete="off">

                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group bank-area <?php echo e($errors->has('issuing_bank_name') ? 'has-error' :''); ?>" style="display: none">
                            <label class="col-sm-2 control-label">Issuing Bank Name</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Issuing Bank Name" id="issuing_bank_name"
                                       name="issuing_bank_name" value="<?php echo e(empty(old('issuing_bank_name')) ? ($errors->has('issuing_bank_name') ? '' : $receiptPayment->issuing_bank_name) : old('issuing_bank_name')); ?>">

                                <?php $__errorArgs = ['issuing_bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group bank-area <?php echo e($errors->has('issuing_branch_name') ? 'has-error' :''); ?>" style="display: none">
                            <label class="col-sm-2 control-label">Issuing Branch Name</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Issuing Branch Name" id="issuing_branch_name"
                                       name="issuing_branch_name" value="<?php echo e(empty(old('issuing_branch_name')) ? ($errors->has('issuing_branch_name') ? '' : $receiptPayment->issuing_branch_name) : old('issuing_branch_name')); ?>">

                                <?php $__errorArgs = ['issuing_branch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Date </label>

                            <div class="col-sm-10">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" id="date" name="date"
                                           value="<?php echo e(old('date',date('d-m-Y',strtotime($receiptPayment->date)))); ?>" autocomplete="off">
                                </div>
                                <!-- /.input group -->

                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                       


















                        <div class="form-group <?php echo e($errors->has('note') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Note</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Note" id="note"
                                       name="note" value="<?php echo e(empty(old('note')) ? ($errors->has('note') ? '' : $receiptPayment->notes) : old('note')); ?>">

                                <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $(function () {
            intSelect2
            //Date picker
            $('#cheque_date').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                orientation: 'bottom'
            });

            $('.date-picker').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
            });

            $('#modal-order').change(function () {
                var orderId = $(this).val();
                $('#modal-order-info').hide();

                if (orderId != '') {

                    $.ajax({
                        method: "GET",
                        url: "<?php echo e(route('client_payment.order_details')); ?>",
                        data: { orderId: orderId }
                    }).done(function( response ) {
                        $('#modal-order-info').html('<strong>Total: </strong>৳ '+parseFloat(response.total)+' <strong>Paid: </strong>৳ '+parseFloat(response.paid)+' <strong>Due: </strong>৳ '+parseFloat(response.due));
                        $('#modal-order-info').show();
                    });
                }
            });

            $('#modal-order').trigger('change');

            $("#payment_type").change(function (){
                var payType = $(this).val();
                if(payType != ''){
                    if(payType == 1){
                        $(".bank-area").show();
                    }else{
                        $(".bank-area").hide();
                    }
                }
            })

            $("#payment_type").trigger("change");

            $("#payment_step_show").change(function (){
                var payType = $(this).val();

                if(payType != ''){
                    if(payType == 3){
                        $(".payment-step-show").show();
                    }else{
                        $(".payment-step-show").hide();
                    }
                }
            })

            $("#payment_step_show").trigger("change");
        });

        function intSelect2(){
            $('.select2').select2()
            $('#account').select2({
                ajax: {
                    url: "<?php echo e(route('account_head_code.json')); ?>",
                    type: "get",
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            searchTerm: params.term // search term
                        };
                    },
                    processResults: function (response) {
                        //console.log(response);
                        return {
                            results: response
                        };
                    },
                    cache: true
                }
            });
            $('#account').on('select2:select', function (e) {
                var data = e.params.data;
                alert(data);
                var index = $("#account").index(this);
                $('#account_name:eq('+index+')').val(data.text);
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hm_engineering\resources\views/accounts/receipt/details_edit.blade.php ENDPATH**/ ?>