<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class EstimateProject extends Model
{
    //
}
