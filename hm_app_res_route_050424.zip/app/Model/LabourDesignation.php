<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LabourDesignation extends Model
{
    protected $guarded = [];
}
